from django.apps import AppConfig


class VisualConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'visual'
    verbose_name = "可视化"
