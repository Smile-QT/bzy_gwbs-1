# -*- coding: utf-8 -*-
# @Time    : 12/06/2021 10:44
# @Author  : Spring
# @FileName: lib.py
# @Software: PyCharm
def render_json(data, code):

    return None
