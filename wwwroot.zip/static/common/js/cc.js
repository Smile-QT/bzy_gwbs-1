/*这里是自定义jQuery*/
$(function(){

})
