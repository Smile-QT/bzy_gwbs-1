# -*- coding: utf-8 -*-
# @Time    : 12/06/2021 10:11
# @Author  : Spring
# @FileName: errors.py
# @Software: PyCharm
OK = 200
SUCCESS = 200
LOGIN_REQUIRE = 1001
USER_NOT_EXIST = 1002
